﻿using System;
using System.Threading;
using System.IO;
using System.Web.Script.Serialization;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;

namespace LinnOrderProc
{
    class OrderProcessor
    {
        /// <summary>
        /// This class implements funtionality to monitor, process and output the order information
        /// *** There is no data deletion contined in here, it was not specified what to do
        /// with internal data once it had been processed***
        /// </summary>
        string inputDir, outputDir;
        int pollTime;

        static readonly string ordersLabel = "orders";
        static readonly string orderItemsLabel = "order items";
        static readonly string orderShipmentsLabel = "order shipments";

        private Dictionary<string, Order> dictOrders = new Dictionary<string, Order>();

        private List<string> filesKnown;

        /// <summary>
        /// Primary functional routine - poll incoming folder, pass data accordingly
        /// (not overly happy about it all being in the contstructor, but without neednig to spin of 
        /// a separate thread, it seems needels to enter here, only to call onto another routine)
        /// </summary>
        /// <param name="inputDir"></param>
        /// <param name="outputDir"></param>
        /// <param name="pollTime"></param>
        public OrderProcessor(string inputDir, string outputDir, int pollTime = 5000)
        {
            this.inputDir = inputDir;
            this.outputDir = outputDir;
            this.pollTime = pollTime; // could be passed in on cmdline

            // Forever loop - 
            // not really seeing the need for a thread here, as it won't really do much
            // more, and as its a console app, the close button will kill everything anyways.
            // Implement a thread if future specs require it....
            while (true)
            {
                // enumerate the files in the 'incoming' dir - match against the 
                // existing list of known files
                IEnumerable<string> filesNew = Directory.EnumerateFiles(inputDir);
                foreach (string fileNew in filesNew)
                {
                    bool newFileFound = true;
                    if (filesKnown != null)
                    { 
                        foreach (string fileKnown in filesKnown)
                        {
                            if (fileNew == fileKnown)
                                newFileFound = false;
                        }
                    }
                    if (newFileFound)
                    {
                        ParseIncomingFile(fileNew);
                    }
                }
                // save the list of known files
                filesKnown = filesNew.ToList();

                Thread.Sleep(pollTime);
            }
        }

        // handle incoming data file - check for valid data type
        private void ParseIncomingFile(string fullpath)
        {
            if (fullpath.EndsWith(".json"))
            {
                string data = null;
                try
                {
                    data = File.ReadAllText(fullpath);
                    if( data != null && data.Length > 0)
                    {
                        // have to do some clunky string matching to determine what objects are in the data.  One of the 
                        // test data files is noted as 'orders' in the data, but actually contains shipping data - have
                        // taken liberty of correcting error and coded accordingly, otherwise would need more clunky 
                        // string matching further withing the data.
                        // (would really love to find a more elegant way of doing this!)
                        string typeVal = data.Substring(0, data.IndexOf(":")); 

                        if (typeVal.Contains(ordersLabel)) // 'order' data
                        {
                            OrdersCache orders = JsonConvert.DeserializeObject<OrdersCache>(data);
                            ProcessIncomingOrderData(ref orders);
                            OutputOrderData();
                        }
                        else if (typeVal.Contains(orderItemsLabel)) // 'order item' data
                        {
                            OrderItemsCache orderItems = JsonConvert.DeserializeObject<OrderItemsCache>(data);
                            if (orderItems.count > 0)
                            {
                                ProcessIncomingOrderItemData(ref orderItems);
                                OutputOrderData();
                            }
                            else
                            {
                                Console.WriteLine("OrderItems were received, but were not extrapolated correctly.");
                            }
                        }
                        else if (typeVal.Contains(orderShipmentsLabel)) // 'order shipment' data
                        {
                            OrderShipmentsCache orderShipments = JsonConvert.DeserializeObject<OrderShipmentsCache>(data);
                            ProcessIncomingOrderShipmentData(ref orderShipments);
                            OutputOrderData();
                        }
                        Console.WriteLine("Processed file: {0}", fullpath);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception caught processing incoming data: File: {0}, Error = {1}",
                                                                            fullpath, e);
                }
            }
        }


        // generate csv data to be output to file
        private void OutputOrderData()
        {
            foreach( string key in dictOrders.Keys)
            {
                Order order = dictOrders[key];
                if( order != null && order.processed == false && order.initialised == true && 
                    order.GetOrderItemsCount() > 0 && order.orderShipmentDetails != null)
                {
                    // build our output string by rolling ruond the orders, checking which ones are valid
                    // and then extracting data from each.
                    string outputOrderInfo = order.GetOutputString() + ",";
                    // orderItem details
                    IEnumerator<KeyValuePair<string, OrderItem>> iter = order.GetOrderItemsEnumerator();
                    string outputOrderItemInfo = string.Empty;
                    while (iter.MoveNext())
                    {
                        outputOrderItemInfo += iter.Current.Value.GetOutputString() + ",";
                    }
                    //orderShipment details
                    string outputOderShipmetnInfo = string.Empty;
                    outputOderShipmetnInfo = order.orderShipmentDetails.GetOutputString();

                    string outputData = outputOrderInfo + outputOrderItemInfo + outputOderShipmetnInfo;

                    if (Directory.Exists(outputDir))
                    {
                        // create filename, remove disallowed chars
                        string fullFilePath = outputDir + "\\" + GetUniqueOrderToken(order).Replace(":", "   ") + ".csv";
                        try
                        {
                            File.WriteAllText(fullFilePath, outputData);
                            order.processed = true; // make sure we don't process again.
                        }
                        catch(Exception e)
                        {
                            Console.WriteLine("Error occurred generating order output file: {0}.  Error: {1}", fullFilePath, e);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Handling the parent 'Order' items data
        /// </summary>
        /// <param name="ordersData"></param>
        private void ProcessIncomingOrderData(ref OrdersCache ordersData)
        {
            int count = ordersData.listOrders.Count;
            foreach (Order order in ordersData.listOrders)
            {
                string uniqueToken = GetUniqueOrderToken(order);
                if (dictOrders.ContainsKey(uniqueToken) == false)
                {
                    order.initialised = true; // non serialised, valid full order incoming
                    dictOrders.Add(uniqueToken, order);
                }
                else
                {
                    // 'tmp' parent order was previously added by incoming item/shipment data,
                    // need to complete the parent object data
                    Order existingOrder = null;
                    dictOrders.TryGetValue(uniqueToken, out existingOrder);
                    existingOrder.name = order.name;
                    existingOrder.surname = order.surname;
                    existingOrder.initialised = true;
                }
            }
        }

        /// <summary>
        /// Spin thru the order items and assocaiate/add with correct order
        /// (1 to many relationship).  Add parent order if it doesn't yet exist,
        /// use item reference and marketplace values combined to provide unique
        /// key.
        /// </summary>
        /// <param name="orderItemsData"></param>
        private void ProcessIncomingOrderItemData(ref OrderItemsCache orderItemsData)
        {
            int count = orderItemsData.listOrderItems.Count;
            foreach (OrderItem orderItem in orderItemsData.listOrderItems)
            {
                string uniqueToken = GetUniqueOrderToken(orderItem);
                // need to ensure parent order exists before we can associate an order item with it.
                EnsureParentOrderExists(orderItem, uniqueToken);

                Order order = null;
                if (dictOrders.TryGetValue(uniqueToken, out order) )
                {
                    if (order.OrderItemExists(uniqueToken) == false )
                        order.AddOrderItem( orderItem);
                }
            }
        }

        /// <summary>
        /// Spin thru the shipping details objects, and associate them with the correct order 
        /// (1 to 1 relationship)
        /// </summary>
        /// <param name="orderShipmentData"></param>
        private void ProcessIncomingOrderShipmentData(ref OrderShipmentsCache orderShipmentData)
        {
            int count = orderShipmentData.listOrderShipments.Count;
            foreach (OrderShipment orderShipment in orderShipmentData.listOrderShipments)
            {
                string uniqueToken = GetUniqueOrderToken(orderShipment);
                // need to ensure parent order exists before we can associate an order shipment with it.
                EnsureParentOrderExists(orderShipment, uniqueToken);

                Order order = null;
                if (dictOrders.TryGetValue(uniqueToken, out order))
                {
                    order.orderShipmentDetails = orderShipment;
                }
            }
        }

        /// <summary>
        /// set of overloaded routines to provide unique key for each type of object.
        /// would like to have done this thru inheritance and a base class, but had
        /// problems getting the Json deserialize to work with that paradigm.
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        private string GetUniqueOrderToken(Order order)
        {
            return order.orderRef + ":" + order.marketPlace;
        }
        private string GetUniqueOrderToken(OrderItem orderItem)
        {
            return orderItem.orderRef + ":" + orderItem.marketPlace;
        }
        private string GetUniqueOrderToken(OrderShipment orderShipment)
        {
            return orderShipment.orderRef + ":" + orderShipment.marketPlace;
        }


        /// <summary>
        /// As data can come in randomly, need to ensure we've taken account of it, and 
        /// have valid parent object to associate the data with.
        /// </summary>
        /// <param name="orderItem"></param>
        /// <param name="key"></param>
        void EnsureParentOrderExists(OrderItem orderItem, string key)
        {
            if (dictOrders.ContainsKey(key) == false)
            {
                dictOrders.Add(key, new Order(orderItem.orderRef, orderItem.marketPlace, "", ""));
            }
        }

        void EnsureParentOrderExists(OrderShipment orderShipment, string key)
        {
            if (dictOrders.ContainsKey(key) == false)
            {
                dictOrders.Add(key, new Order(orderShipment.orderRef, orderShipment.marketPlace, "", ""));
            }
        }
    }
}
