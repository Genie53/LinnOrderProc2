﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Reflection;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace LinnOrderProc
{

    /// <summary>
    /// The classes contined in this file are small enough to not really need expanding out into their own 
    /// code files
    /// </summary>


    /// Provide some functional classes to allow the remapping of properties 
    /// to custom names notated in the incoming data files
    #region JsonDeserialiserClasses
    class OrdersCache
    {
        [JsonProperty("orders")]
        public List<Order> listOrders { get; set; }
    }
    class OrderItemsCache
    {
        [JsonProperty("order items")]
        public List<OrderItem> listOrderItems { get; set; }
        [JsonIgnore]
        public int count { get { return listOrderItems.Count(); } }
    }
    class OrderShipmentsCache
    {
        [JsonProperty("order shipments")]
        public List<OrderShipment> listOrderShipments { get; set; }
    }
    #endregion

    #region Order
    class Order 
    {
        public Order(string orderRef, string marketPlace, string name, string surname)
        {
            this.orderRef = orderRef;
            this.marketPlace = marketPlace;
            this.name = name;
            this.surname = surname;
        }

        // decorate the required properties to enable custom
        // remapping of property names when deserialising
        [JsonProperty("order reference")]
        public string orderRef { get; set; }
        [JsonProperty("marketplace")]
        public string marketPlace { get; set; }
        [JsonProperty("name")]
        public string name { get; set; }
        [JsonProperty("surname")]
        public string surname { get; set; }

        // flag to determine whether this object has been completely setup
        // OrderProcessing will create a temp object if OrderItem or OrderShipment
        // data comes in before the parent order is received.
        public bool initialised = false;

        // There's no indication of what to do after an order is printed (delete order?)
        // so am implementing a flag to show order has been printed and not to be printed again.
        public bool processed = false;

        // Local cache of items relevant to this order
        private Dictionary<string, OrderItem> orderItems = new Dictionary<string, OrderItem>();
        #region OrderItemsAccesors
        /// <summary>
        /// Provide some access to the data - don't really want to make the 
        /// core data component public
        /// </summary>
        /// <param name="item"></param>
        public void AddOrderItem(OrderItem item)
        {
            // item.orderItemNum should be unique within its parent order
            orderItems[item.orderItemNum] = item;
        }
        public bool OrderItemExists( string key)
        {
            return orderItems.ContainsKey(key);
        }
        public OrderItem GetOrderItem(ref string orderItemNum)
        {
            OrderItem item = null;
            orderItems.TryGetValue(orderItemNum, out item);
            return item;
        }
        public void RemoveOrderItem( ref string orderItemNum)
        {
            if (orderItemNum != null) // save having to handling an exception
            {
                orderItems.Remove(orderItemNum);
            }
        }
        public void ClearAllOrderItems()
        {
            orderItems.Clear();
        }
        public int GetOrderItemsCount()
        {
            return orderItems.Count;
        }
        /// <summary>
        /// Allow some iterative access
        /// </summary>
        public IEnumerator<KeyValuePair<string, OrderItem>> GetOrderItemsEnumerator()
        {
            return orderItems.AsEnumerable().GetEnumerator(); 
        }
        #endregion OrderListAccesors

        // local instance of shipment data relevant to this order
        public OrderShipment orderShipmentDetails { get; set; } = null;

        // produce the required csv string
        public string GetOutputString()
        {
            return string.Format("{0},{1},{2},{3}", orderRef, marketPlace, name, surname);
        }
    }
    #endregion

    #region OrderItem
    class OrderItem
    {
        public OrderItem(string orderRef, string marketPlace, string orderItemNum, string sku,
                                string pricePerUnit, string quantity)
        {
            this.orderRef = orderRef;
            this.marketPlace = marketPlace;
            this.orderItemNum = orderItemNum;
            this.sku = sku;
            this.pricePerUnit = pricePerUnit;
            this.quantity = quantity;
        }

        // decorate the required properties to enable custom
        // remapping of property names when deserialising
        [JsonProperty("order reference")]
        public string orderRef { get; set; }
        [JsonProperty("marketplace")]
        public string marketPlace { get; set; }
        [JsonProperty("order item number")]
        public string orderItemNum { get; set; } // should be unique within its parent order
        [JsonProperty("sku")]
        public string sku { get; set; }
        [JsonProperty("price per unit")]
        public string pricePerUnit { get; set; }
        [JsonProperty("quantity")]
        public string quantity { get; set; }

        // produce the required csv string
        public string GetOutputString()
        {
            return string.Format("{0},{1},{2},{3}", orderItemNum, sku, pricePerUnit, quantity);
        }

    }
    #endregion

    #region OrderShipment
    class OrderShipment
    {
        public OrderShipment(string orderRef, string marketPlace, string shippingService, string postalCode)
        {
            this.orderRef = orderRef;
            this.marketPlace = marketPlace;
            this.shippingService = shippingService;
            this.postalCode = postalCode;
        }

        // decorate the required properties to enable custom
        // remapping of property names when deserialising
        [JsonProperty("order reference")]
        public string orderRef { get; set; }
        [JsonProperty("marketplace")]
        public string marketPlace { get; set; }
        [JsonProperty("postal service")]
        public string shippingService { get; set; }
        [JsonProperty("postcode")]
        public string postalCode { get; set; }

        // produce the required csv string
        public string GetOutputString()
        {
            return string.Format("{0},{1}", shippingService, postalCode);
        }
    }
    #endregion



}
