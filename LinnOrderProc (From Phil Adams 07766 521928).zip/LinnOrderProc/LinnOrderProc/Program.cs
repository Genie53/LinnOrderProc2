﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace LinnOrderProc
{
    class Program
    {

        static void Main(string[] args)
        {
            CmdLineParser clp = new CmdLineParser();
            if (clp.ProcessCmdArgs(ref args))
            {
                // multiple instances of an order processor can be instantiated, with differing
                // folder/poll info for each.
                OrderProcessor proc = new OrderProcessor(clp.GetCmdLineParam(CmdLineParser.inputPath), 
                                                        clp.GetCmdLineParam(CmdLineParser.outputPath));

            }
        }
    }
}
