Phil Adams - philadams@rocketmail.com - 07766 521928

Some notes on this programming test.

* one of the data files had incorrect data in it, had to re-label Json data accordingly (otherwise there'd have been no shipment data!)
* one of the order item number's was 'null', when the spec stated they would be unique within order, so have adjusted accordingly
* no data is deleted, when the files are processed and csv's generated, there's no stipulation of data management - have assumed 'keep'
* DataObjects should be split into separate files if they grow anymore (borderline decision - have left them all in one file for now)
