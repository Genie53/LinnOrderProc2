﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace LinnOrderProc
{
    /// <summary>
    /// This class provides functioanlity required to process and extract values out of the 
    /// passed-in cmdline arguments, and store them in a Dictionary, keyed by their
    /// relevant argument.
    /// </summary>
    class CmdLineParser
    {
        // To add new cmdline args, add a const string here for it, then add it 
        // to the 'possibleCmdLineArgs' dictionary initialiser below
        public static readonly string inputPath = "inputPath"; // path to monitor for file changes
        public static readonly string outputPath = "outputPath"; // path to output csv file to
        public static readonly string pollTime = "pollTime"; // period of sleep for processing loop

        // Declare and initialise a list of possible cmdline args - easily extendable, used
        // to spin round all passed in args, extracting recognised ones and adding them to 
        // the 'Processed' Dictionary
        private readonly Dictionary<string, string> possibleCmdLineArgs = new Dictionary<string, string>()
        {
            {"/i:", inputPath},
            {"/o:", outputPath},
            {"/p:", pollTime}

        };

        // the processed incoming arguments, effectively needs to be readonly, single instance
        private static Dictionary<string, string> processedCmdLineArgs = new Dictionary<string, string>();
        /// <summary>
        /// Provide some readonly access to the cmdline params
        /// </summary>
        public IEnumerable<KeyValuePair<string, string>> GetCmdLineParamsIterator
        {
            get { return processedCmdLineArgs.AsEnumerable(); }
        }

        /// <summary>
        /// provide access to params without giving access to dictionary
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public string GetCmdLineParam(string key)
        {
            string val = string.Empty; 
            processedCmdLineArgs.TryGetValue(key, out val); // should cater for key not present
            return val;
        }


        /// <summary>
        /// ProcessCmdArgs - Determine running context, errors/user info shown according to context
        /// 
        /// </summary>
        /// <param name="argsIn"></param>
        public bool ProcessCmdArgs(ref string[] argsIn)
        {
            switch (argsIn.Count())
            {
                case 1:
                    {
                        if (argsIn[0] == "?")
                        {
                            Console.WriteLine(GenerateHelpString());
                            return false; // nothing else to do
                        }
                    }
                    break;
                case 2:
                    return TranslateCmdLine(ref argsIn, ref processedCmdLineArgs);
                // break; (not needed)

                default:
                    Console.WriteLine("Invalid command line parameters");
                    break;

            }
            return false;
        }

        /// <summary>
        /// DetermineRuntimeFodlers 
        /// Spin round all passed in args, looking for relevant ones  to thsi routine (input/output folders)
        /// Using a loop with a params dictionary should make it easier to extend the params 
        /// list in the future;
        /// </summary>
        /// <param name="argsIn"></param>
        bool TranslateCmdLine(ref string[] argsIn, ref Dictionary<string, string> processedCmdLineArg)
        {
            try
            {
                // spin thru incoming params, resolve runtime values (in/out folders)
                foreach (string arg in argsIn)
                {
                    // try to match each incoming param with all the possible known cmdline args,
                    // save each matched/recognised one into a static Dict for the rest of the program to use
                    foreach (string key in possibleCmdLineArgs.Keys)
                    {
                        if (arg.IndexOf(key) > -1)
                        {
                            processedCmdLineArg.Add(possibleCmdLineArgs[key], arg.Substring(key.Length));
                        }
                    }
                }
                // sanity checking passed-in args - can't run without valid Folders to work from 
                // other future params may mean this section needs extending.
                if (Directory.Exists(processedCmdLineArg[inputPath]) == false)
                {
                    Console.WriteLine("Monitored Folder does not exist, please specify a valid folder path.");
                    return false;
                }
                if (Directory.Exists(processedCmdLineArg[outputPath]) == false)
                {
                    Console.WriteLine("Output Folder does not exist, please specify a valid folder path.");
                    return false;
                }

                // all good
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occured when attempting to parse the cmdline arguments: {0}, please check and try again.",
                                                                                                        ex.Message);
                Console.WriteLine(GenerateHelpString());
            }
            finally
            {
                // always printout what we know, so use can determine which arguments are duff
                Console.WriteLine("Determined CmdLine args:");
                foreach (string key in processedCmdLineArg.Keys)
                {
                    Console.WriteLine("\tParam: {0}, value: \"{1}\"", key, processedCmdLineArg[key]);
                }

            }

            // if we're here, something went wrong, so signify failure to calling routine.
            return false;
        }

        string GenerateHelpString()
        {
            string msg = "Possible cmdline params:\r\n\t";
            foreach (string key in possibleCmdLineArgs.Keys)
            {
                msg += key + "\"<" + possibleCmdLineArgs[key] + ">\"" + "\r\n\t";
            }
            return msg;
        }
    }
}
